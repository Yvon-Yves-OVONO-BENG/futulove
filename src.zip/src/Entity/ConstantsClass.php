<?php

namespace App\Entity;

class ConstantsClass
{
    public const ROLE_ADMINISTRATEUR = 'ROLE_ADMINISTRATEUR';
    public const ROLE_MEMBRE = 'ROLE_MEMBRE';
    public const GRATUIT = 'GRATUIT';
    public const PREMIUM = 'PREMIUM';
    public const VIP = 'VIP';

}
