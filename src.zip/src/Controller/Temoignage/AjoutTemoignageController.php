<?php

namespace App\Controller\Temoignage;

use App\Entity\PhotoTemoignage;
use App\Entity\Temoignage;
use App\Form\TemoignageType;
use App\Repository\TemoignageRepository;
use DateTime;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Contracts\Translation\TranslatorInterface;

#[IsGranted('ROLE_USER', message: 'Accès refusé. Connectez-vous')]
#[Route('/temoignage')]
class AjoutTemoignageController extends AbstractController
{
    public function __construct(
        protected EntityManagerInterface $em,
        protected TranslatorInterface $translator,
        protected TemoignageRepository $temoignageRepository,
    )
    {}

    #[Route('/ajout-temoignage', name: 'ajout_temoignage')]
    public function ajoutTemoignage(Request $request): Response
    {
        $mySession = $request->getSession();

        #je récupère mes témoignages
        $mesTemoignages = $this->temoignageRepository->findBy([
            'supprime' => 0,
            'createdBy' => $this->getUser(),
        ]);
        
        $temoignage = new Temoignage();
        $form = $this->createForm(TemoignageType::class, $temoignage);
        $form->handleRequest($request);
        
        if ($form->isSubmitted() && $form->isValid()) 
        {
            // dd($form->get('photoTemoignages')->getData());
            #je récupère les fichiers
            $photos = $form->get('photoTemoignages')->getData();
            
            foreach ($photos as $photo) 
            {
                $photoTemoignage = new PhotoTemoignage();

                #je génère un nom unique pour chaque image
                $nouveauNomFichier = uniqid('', true).'.'.$photo->guessExtension();
                $photo->move(
                    $this->getParameter('photoTemoignages'),
                    $nouveauNomFichier
                );

                $photoTemoignage->setPhotoTemoignage($nouveauNomFichier)
                                ->setSupprime(0);

                $temoignage->addPhotoTemoignage($photoTemoignage)
                            ->setCreatedAt(new DateTime('now'))
                            ->setCreatedBy($this->getUser())
                            ->setSlug(md5(uniqid('', true)))
                            ->setNombreVues(0)
                            ->setSupprime(0)
                            ;
            }

            $this->em->persist($temoignage);
            $this->em->flush();

            $this->addFlash('info', $this->translator->trans('Témoignage enregistré avec succès !'));
                
            $mySession->set('ajout', 1);

            #je vide le formulaire
            $temoignage = new Temoignage();
            $form = $this->createForm(TemoignageType::class, $temoignage);

        }

        return $this->render('temoignage/ajoutTemoignage.html.twig', [
            'slug' => "",
            'mesTemoignages' => $mesTemoignages,
            'formTemoignage' => $form->createView(),
        ]);
    }
}
