<?php

namespace App\Controller\Groupe;

use App\Repository\AmitieRepository;
use App\Repository\GroupeRepository;
use App\Repository\MembreGroupeRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RequestStack;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;

#[IsGranted('ROLE_USER', message: 'Accès refusé. Connectez-vous')]
#[Route('/groupe')]
class AfficherGroupeController extends AbstractController
{
    public function __construct(
        protected RequestStack $request,
        protected EntityManagerInterface $em,
        protected AmitieRepository $amitieRepository,
        protected GroupeRepository $groupeRepository,
        protected CsrfTokenManagerInterface $csrfTokenManager,
        protected MembreGroupeRepository $membreGroupeRepository,
    )
    {}

    #[Route('/afficher-groupe/{slug}', name: 'afficher_groupe')]
    public function afficherGroupe(Request $request, string $slug): Response
    {
        # je récupère ma session
        $maSession = $request->getSession();
        
        #mes variables témoin pour afficher les sweetAlert
        $maSession->set('ajout', null);
        $maSession->set('misAjour', null);
        $maSession->set('suppression', null);
        
        $groupes = [];
        $groupe = $this->groupeRepository->findOneBySlug([
            'slug' => $slug
        ]);

        /////liste des amis
        $amis = $this->amitieRepository->rechercheAmisUser($this->getUser());

        $tousLesGroupes = $this->groupeRepository->findBy([
            'supprime' => 0,
        ]);

        foreach ($tousLesGroupes as $unGroupe) 
        {
            if ($unGroupe->getId() != $groupe->getId() ) 
            {
                $groupes[] = $unGroupe;
            }
        }

        $lesMembresDuGroupe = [];
        $demandesAdhesions = [];

        foreach ($groupe->getMembreGroupes() as $membreGroupe) 
        {
            if ($membreGroupe->isSupprime() == 0 && $membreGroupe->isEtatDemande() == 1) 
            {
                $lesMembresDuGroupe[] = $membreGroupe;
            }
        }

        foreach ($groupe->getMembreGroupes() as $membreGroupe) 
        {
            if ($membreGroupe->isSupprime() == 0 && $membreGroupe->isEtatDemande() == 0) 
            {
                $demandesAdhesions[] = $membreGroupe;
            }
        }
        
        #test d'appartenance dans le groupe
        $suisJeDansLeGroupe = $this->membreGroupeRepository->findOneBy([
            'groupe' => $groupe,
            'etatDemande' => 0,
            'membre' => $this->getUser()
        ]);
       
        
        # je crée mon CSRF pour sécuriser mes requêtes
        $csrfToken = $this->csrfTokenManager->getToken('demandeAmitie')->getValue();

        #je retourne au profil
        return $this->render('groupe/afficherGroupe.html.twig', [
            'amis' => $amis,
            'groupe' => $groupe,
            'groupes' => $groupes,
            'csrf_token' => $csrfToken,
            'profil' => $this->getUser(),
            'demandesAdhesions' => $demandesAdhesions,
            'lesMembresDuGroupe' => $lesMembresDuGroupe,
            'suisJeDansLeGroupe' => $suisJeDansLeGroupe,
        ]);
    }
}
